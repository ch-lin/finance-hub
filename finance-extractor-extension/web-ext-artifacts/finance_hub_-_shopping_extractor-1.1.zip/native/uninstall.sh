#!/bin/bash
# =============================================================================
# The MIT License (MIT)
#
# Copyright (c) 2025 Che-Hung Lin
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# =============================================================================

# Define Chrome NativeMessagingHosts directory for Mac
TARGET_DIR="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
MANIFEST_NAME="ch.lin.finance.hub.native.json"
TARGET_FILE="$TARGET_DIR/$MANIFEST_NAME"
HOST_EXEC_NAME="ch.lin.finance.hub.native.py"
HOST_TARGET_PATH="$TARGET_DIR/$HOST_EXEC_NAME"

echo "=== Finance Hub Extension Native Host Uninstaller ==="

if [ -f "$TARGET_FILE" ]; then
    rm "$TARGET_FILE"
    echo "✅ Successfully removed $TARGET_FILE"
    
    if [ -f "$HOST_TARGET_PATH" ]; then
        rm "$HOST_TARGET_PATH"
        echo "✅ Successfully removed $HOST_TARGET_PATH"
    fi
    
    echo "The Native Host has been uninstalled. The extension will automatically revert to raw HTML save mode."
else
    echo "⚠️ Native Host manifest not found at $TARGET_FILE."
    echo "It seems it was already uninstalled or never installed."
fi
