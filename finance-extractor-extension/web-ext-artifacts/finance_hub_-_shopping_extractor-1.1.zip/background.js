/*=============================================================================
 * The MIT License (MIT)
 *
 * Copyright (c) 2025 Che-Hung Lin
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *===========================================================================*/

const NATIVE_HOST_NAME = 'ch.lin.finance.hub.native';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'pingNativeHost') {
        chrome.runtime.sendNativeMessage(NATIVE_HOST_NAME, { command: "ping" }, (response) => {
            if (chrome.runtime.lastError) {
                console.warn("Native host not found or error:", chrome.runtime.lastError.message);
                sendResponse({ installed: false });
            } else {
                sendResponse({ installed: true });
            }
        });
        return true; // Keep message channel open for async response
    } else if (request.action === 'triggerNativeSave') {
        chrome.runtime.sendNativeMessage(NATIVE_HOST_NAME, { command: "save_page" }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Failed to trigger native save:", chrome.runtime.lastError.message);
                sendResponse({ success: false, error: chrome.runtime.lastError.message });
            } else {
                sendResponse({ success: true });
            }
        });
        return true;
    }
});
