/*=============================================================================
 * The MIT License (MIT)
 *
 * Copyright (c) 2025 Che-Hung Lin
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *===========================================================================*/
document.addEventListener('DOMContentLoaded', () => {
    const urlInput = document.getElementById('backendBaseUrl');
    const dryRunInput = document.getElementById('dryRun');
    const saveBtn = document.getElementById('saveBtn');
    const statusDiv = document.getElementById('status');
    const defaultBaseUrl = "http://localhost:8080";

    // Load saved Base URL and dryRun state
    chrome.storage.sync.get(['backendBaseUrl', 'dryRun'], (result) => {
        if (result.backendBaseUrl) {
            urlInput.value = result.backendBaseUrl;
        } else {
            urlInput.value = defaultBaseUrl;
        }
        
        // Default dryRun to false if not set
        dryRunInput.checked = result.dryRun === undefined ? false : result.dryRun;
    });

    // Save Base URL and dryRun state
    saveBtn.addEventListener('click', () => {
        let newUrl = urlInput.value.trim();
        if (!newUrl) {
            newUrl = defaultBaseUrl;
            urlInput.value = newUrl;
        }
        
        const isDryRun = dryRunInput.checked;

        chrome.storage.sync.set({ backendBaseUrl: newUrl, dryRun: isDryRun }, () => {
            statusDiv.style.display = 'block';
            setTimeout(() => {
                statusDiv.style.display = 'none';
            }, 2000);
        });
    });
});
